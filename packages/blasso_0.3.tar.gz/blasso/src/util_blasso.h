double	easy_samp(int, double*, double*, double*, double*, double);
double	rej_samp(int, double*, double*, double*, double, double, int);
void		GetSlopeInt(int, double*, double*, double*, double*, double, double*,int);
double	dlogtarget(double, double, double);
double	logtarget(double, double, double, double);
int		sig2_rej_samp(double*, double, double, double, double, int, int*);
